# betterShinden
Python API for shinden (https://shinden.pl/).
